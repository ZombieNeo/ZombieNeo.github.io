buscount = 0
planecount = 0
traincount = 0


print("welcome")
print("\n")
save = open("save.txt","w")
ceo = input("enter CEO name ")
print("\n")
company = input("enter company name ")
print("\n")
t = open("towns.txt","r")#disbale for mobile
file_contents = t.read()
print (file_contents)
print("\n")
hq = input("enter town to put your HQ ")
money = 10000
save.write(str(ceo)+"\n")
save.write(str(company)+"\n")
save.write(str(money)+"\n")
print("\n")
print("\n")
print("\n")
busstart1 = input("your HQ is in "+str(hq)+" where do you want to place bus stops, north, east, south, west? ")
if busstart1 == "north":
    print("your first stop is in the north of " +str(hq))
    save.write(str(hq)+","+str(busstart1)+"\n")
    pass
if busstart1== "east":
    print("your first stop is in the east of " +str(hq))
    save.write(str(hq)+","+str(busstart1)+"\n")
    pass
if busstart1== "south":
    print("your first stop is in the south of " +str(hq))
    save.write(str(hq)+","+str(busstart1)+"\n")
    pass
if busstart1 == "west":
    print("your first stop is in the west of " +str(hq))
    save.write(str(hq)+","+str(busstart1)+"\n")
    pass

print("\n")
print (file_contents)
print("-----------------------------------------------------------------")
dest1 = input("Where do you want it to go? ")
print("\n") 
destrection1 = input("where do you want to place bus stops, north, east, south, west? ")
save.write(str(dest1)+","+str(destrection1)+"\n")
#----------------------------------------------------------------------------------------------------------------------------------------------- end of intro
print("\n")
print("bus costs 200 train costs 2000 plane costs 4000")
#buying code 
vehiclebuy = input("do you want to buy a vehicle? Bus, plane, train. PRESS ENTER TO SKIP ")
if vehiclebuy == "bus":
    print("BUS HAS BEEN BOUGHT!! AND STORED")
    z = open("bus.txt","a")
    buscount = buscount + 1
    z.write(str(buscount))
    money = money - 200
    print("\n")
    print(str(money))
    print("pounds left")
    z.close()
    z = open("towns.txt","r")
    file_contents = z.read()
    print (file_contents) 
    z.close()
    print("\n")
    print("\n")
    print("\n")
    print("\n")
    busroutestart= input("where do you want it to start? ")
    direction = input("north, east, south, west?")
    bussv= open("busroute.txt","a")
    z = open("towns.txt","r")
    file_contents = z.read()
    print (file_contents) 
    z.close()    
    busrouteend = input("where do you want to stop?")
    direction2 = input("north, east, south, west?")
    bussv.write(str(busroutestart)+","+str(direction)+"--->"+busrouteend+","+direction2+"\n")
    pass    
    
    
if vehiclebuy == "plane":
    print("PLANE HAS BEEN BOUGHT!! AND STORED")
    z = open("plane.txt","a")
    planecount = planecount + 1
    z.write(str(planecount))
    money = money - 4000
    print("\n")
    print(str(money))
    print("pounds left")
    z.close()
    z = open("towns.txt","r")
    file_contents = z.read()
    print (file_contents) 
    z.close()
    print("\n")
    print("\n")
    print("\n")
    print("\n")
    planeroutestart= input("where do you want it to start? ")
    direction = input("north, east, south, west?")
    planesv= open("planeroute.txt","a")
    z = open("towns.txt","r")
    file_contents = z.read()
    print (file_contents) 
    z.close()    
    planerouteend = input("where do you want to stop?")
    direction2 = input("north, east, south, west?")
    planesv.write(str(planeroutestart)+","+str(direction)+"--->"+planerouteend+","+direction2+"\n")
    pass    
    
if vehiclebuy == "train":
    print("TRAIN HAS BEEN BOUGHT!! AND STORED")
    z = open("train.txt","a")
    traincount = traincount + 1
    z.write(str(traincount))
    money = money - 2000
    print("\n")
    print(str(money))
    print("pounds left")
    z.close()
    z = open("towns.txt","r")
    file_contents = z.read()
    print (file_contents) 
    z.close()
    print("\n")
    print("\n")
    print("\n")
    print("\n")
    trainroutestart= input("where do you want it to start? ")
    direction = input("north, east, south, west?")
    trainsv= open("trainroute.txt","a")
    z = open("towns.txt","r")
    file_contents = z.read()
    print (file_contents) 
    z.close()    
    trainrouteend = input("where do you want to stop?")
    direction2 = input("north, east, south, west?")
    trainsv.write(str(trainroutestart)+","+str(direction)+"--->"+trainrouteend+","+direction2+"\n")
    pass
 



