#disease game
import winsound
import time
from random import *
celltotal = 6
cellcount = 0
#each cell has 100 people
speed_default = 1 #default spread rate
points = 0
rand = randint(1,1000)
s = 1
print("watch everyone die.")
time.sleep(3)
print("every 100 people infected kills a Continent (fuck Antarctica).")
time.sleep(0.5)
winsound.PlaySound("weeb.wav", winsound.SND_LOOP + winsound.SND_ASYNC)
def infect_true():
    global cellcount
    cellcount = cellcount + speed_default
    print("infected: "+str(cellcount)+" innocent people")
    time.sleep(int(s))       
    pass
def infect_false():
    pass

while True:
    x = randint(1,5)
    if x == 5:
        infect_true()
        time.sleep(2)
        if cellcount == 100:
            f = open("1cells.txt","r")
            file_contents = f.read()
            print(file_contents)
            points = points + rand
            print("you have: "+str(points))
            pass
        
        if cellcount == 200:
            f = open("2 cells.txt","r")
            file_contents = f.read()
            print(file_contents)
            points = points + rand
            print("you have: "+str(points))
            pass
    if cellcount == 300:
            f = open("3 cells.txt","r")
            file_contents = f.read()
            print(file_contents)
            points = points + rand
            print("you have: "+str(points))
            pass
 
    if cellcount == 400:
            f = open("4 cells.txt","r")
            file_contents = f.read()
            print(file_contents)
            points = points + rand
            print("you have: "+str(points))
            pass
    if cellcount == 500:
            f = open("5cells.txt","r")
            file_contents = f.read()
            print(file_contents)
            points = points + rand
            print("you have: "+str(points))
            pass
    if cellcount == 600:
            f = open("6 cells.txt","r")
            file_contents = f.read()
            print(file_contents)
            points = points + rand
            print("you have: "+str(points))
            print("ALL HUMAN LIFE HAS BEEN ERADICATED!")
            end = input("press any key to continue")
            pass
    else:
        infect_false()
        time.sleep(2)
        pass
    
 
    
