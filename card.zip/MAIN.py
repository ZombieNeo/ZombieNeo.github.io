f = open("scores.txt", "a")
import winsound
p1score = 0
p2score = 0
import time
from random import *
g = 0
print("welcome to play your cards right!!")
print("\n")
time.sleep(g)
p1 = input("hey player 1 enter ur name! ")
print("awesome!, nice to meet you "+str(p1)+"!")
print("\n")
time.sleep(g)
p2 = input("hey player 2 enter ur name! ")
print("awesome!, nice to meet you "+str(p2)+"!")
#------------------------------end of player data collection
print("\n")
time.sleep(g)

#------------------------------end of who goes first
card1p1 = randint(1,13)
card2p1 = randint(1,13)
card3p1 = randint(1,13)
card4p1 = randint(1,13)
card5p1 = randint(1,13)
#------------------end of player 1 card gen
card1p2 = randint(1,13)
card2p2 = randint(1,13)
card3p2 = randint(1,13)
card4p2 = randint(1,13)
card5p2 = randint(1,13)
#------------------end of player 2 card gen
print("loading....")
time.sleep(g)
print("loading....")
time.sleep(g)
print("loading....")
print("cards are generated")
time.sleep(g)
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
time.sleep(g)
#rember try and make it so that 11 = jack
# 12 = queen 13= king 1 = ace
print("remember ace is low! these are the rules:")
time.sleep(g)
print("11 = jack")
print("12 = queen")
print("13 = king")
time.sleep(g)
print("after each card is shown you have to decide if the next card is higher or lower. easy right?")
time.sleep(g)
print("lets begin!")
#cue theme song
#-----------------------end of card gen and rules
#add sounds of brucie trhouhhtout 
print("\n")
print("\n")
print("-------------")
print("LETS PLAY!")
print("-------------")
print("\n")
winsound.PlaySound("card.wav", winsound.SND_NOSTOP)
time.sleep(5)
winsound.PlaySound("1.wav", winsound.SND_ASYNC)

p1guess1 = input("Player 1 your first card is " +str(card1p1)+ " is the next card higher or lower? ")
if p1guess1.lower() == "higher":
    print("you guessed higher! ")
    if card2p1 > card1p1:
        print(" correct "+str(card2p1)+ " is bigger than "+str(card1p1))
        p1score = p1score + 1
    else:
        print("you are wrong! "+ str(card2p1)+ " is smaller than "+str(card1p1))
        pass
if p1guess1.lower() == "lower":
    print("you guessed lower! ")
    if card2p1 < card1p1:
        print(" correct "+str(card2p1)+ " is smaller than "+str(card1p1))
        p1score = p1score + 1
    else:
        print("you are wrong! "+ str(card2p1)+ " is bigger than "+str(card1p1))
        pass
if card1p1 == card2p1:
    print("\n")
    print(" bad luck! you lose your turn they are the same!")
    pass
#-----------------------------------------end of round 1
print("\n")
print("\n")
print("-------------")
print("NEXT PLAYER !")
print("-------------")
print("\n")
p2guess1 = input("Player 2 your first card is " +str(card1p2)+ " is the next card higher or lower? ")
if p2guess1.lower() == "higher":
    print("you guessed higher! ")
    if card2p2 > card1p2:
        print(" correct "+str(card2p2)+ " is bigger than "+str(card1p2))
        p2score = p2score + 1
    else:
        print("you are wrong! "+ str(card2p2)+ " is smaller than "+str(card1p2))
        pass
if p2guess1.lower() == "lower":
    print("you guessed lower! ")
    if card2p2 < card1p2:
        print(" correct "+str(card2p2)+ " is smaller than "+str(card1p2))
        p2score = p2score + 1
    else:
        print("you are wrong! "+ str(card2p2)+ " is bigger than "+str(card1p2))
        pass
if card1p2 == card2p2:
    print("\n")
    print(" bad luck! you lose your turn they are the same!")
    pass
#---------------------------------end of round 2
print("\n")
print("\n")
print("-------------")
print("NEXT PLAYER !")
print("-------------")
print("\n")
p2guess1 = input("Player 2 your first card is " +str(card1p2)+ " is the next card higher or lower? ")
if p2guess1.lower() == "higher":
    print("you guessed higher! ")
    if card2p2 > card1p2:
        print(" correct "+str(card2p2)+ " is bigger than "+str(card1p2))
        p2score = p2score + 1
    else:
        print("you are wrong! "+ str(card2p2)+ " is smaller than "+str(card1p2))
        pass
if p2guess1.lower() == "lower":
    print("you guessed lower! ")
    if card2p2 < card1p2:
        print(" correct "+str(card2p2)+ " is smaller than "+str(card1p2))
        p2score = p2score + 1
    else:
        print("you are wrong! "+ str(card2p2)+ " is bigger than "+str(card1p2))
        pass
if card1p2 == card2p2:
    print("\n")
    print(" bad luck! you lose your turn they are the same!")
    pass
#---------------------------------end of round 3
print("\n")
print("\n")
print("-------------")
print("NEXT PLAYER !")
print("-------------")
print("\n")
p2guess1 = input("Player 2 your first card is " +str(card1p2)+ " is the next card higher or lower? ")
if p2guess1.lower() == "higher":
    print("you guessed higher! ")
    if card2p2 > card1p2:
        print(" correct "+str(card2p2)+ " is bigger than "+str(card1p2))
        p2score = p2score + 1
    else:
        print("you are wrong! "+ str(card2p2)+ " is smaller than "+str(card1p2))
        pass
if p2guess1.lower() == "lower":
    print("you guessed lower! ")
    if card2p2 < card1p2:
        print(" correct "+str(card2p2)+ " is smaller than "+str(card1p2))
        p2score = p2score + 1
    else:
        print("you are wrong! "+ str(card2p2)+ " is bigger than "+str(card1p2))
        pass
if card1p2 == card2p2:
    print("\n")
    print(" bad luck! you lose your turn they are the same!")
    pass
#---------------------------------end of round 4
print("\n")
print("\n")
print("-------------")
print("NEXT PLAYER !")
print("-------------")
print("\n")
p2guess1 = input("Player 2 your first card is " +str(card1p2)+ " is the next card higher or lower? ")
if p2guess1.lower() == "higher":
    print("you guessed higher! ")
    if card2p2 > card1p2:
        print(" correct "+str(card2p2)+ " is bigger than "+str(card1p2))
        p2score = p2score + 1
    else:
        print("you are wrong! "+ str(card2p2)+ " is smaller than "+str(card1p2))
        pass
if p2guess1.lower() == "lower":
    print("you guessed lower! ")
    if card2p2 < card1p2:
        print(" correct "+str(card2p2)+ " is smaller than "+str(card1p2))
        p2score = p2score + 1
    else:
        print("you are wrong! "+ str(card2p2)+ " is bigger than "+str(card1p2))
        pass
if card1p2 == card2p2:
    print("\n")
    print(" bad luck! you lose your turn they are the same!")
    pass
#---------------------------------end of round 5
print("\n")
print("\n")
print("-------------")
print("NEXT PLAYER !")
print("-------------")
print("\n")
p2guess1 = input("Player 2 your first card is " +str(card1p2)+ " is the next card higher or lower? ")
if p2guess1.lower() == "higher":
    print("you guessed higher! ")
    if card2p2 > card1p2:
        print(" correct "+str(card2p2)+ " is bigger than "+str(card1p2))
        p2score = p2score + 1
    else:
        print("you are wrong! "+ str(card2p2)+ " is smaller than "+str(card1p2))
        pass
if p2guess1.lower() == "lower":
    print("you guessed lower! ")
    if card2p2 < card1p2:
        print(" correct "+str(card2p2)+ " is smaller than "+str(card1p2))
        p2score = p2score + 1
    else:
        print("you are wrong! "+ str(card2p2)+ " is bigger than "+str(card1p2))
        pass
if card1p2 == card2p2:
    print("\n")
    print(" bad luck! you lose your turn they are the same!")
    pass
#------------------------------end of rounds
print("\n")
time.sleep(2)
print("\n")
time.sleep(2)
print("\n")
time.sleep(2)
print("GAME OVER!!!!!")
print("\n")
time.sleep(2)
print("lets see the scores!")
print("\n")
time.sleep(2)
print(str(p1)+" got "+str(p1score)+ " points")
print("\n")
time.sleep(2)
print(str(p2)+" got "+str(p2score)+ " points")


k=input("press close to exit") 
