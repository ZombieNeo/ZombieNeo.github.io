buscount = 0
planecount = 0
traincount = 0
trainroutecount = 0
money = 1000000000

#buying code 

vehiclebuy = input("do you want to buy a vehicle? Bus, plane, train. PRESS ENTER TO SKIP ")
if vehiclebuy == "bus":
    print("BUS HAS BEEN BOUGHT!! AND STORED")
    z = open("bus.txt","a")
    buscount = buscount + 1
    z.write(str(buscount))
    money = money - 200
    print("\n")
    print(str(money))
    print("pounds left")
    z.close()
    z = open("towns.txt","r")
    file_contents = z.read()
    print (file_contents) 
    z.close()
    print("\n")
    print("\n")
    print("\n")
    print("\n")
    busroutestart= input("where do you want it to start? ")
    direction = input("north, east, south, west?")
    bussv= open("busroute.txt","a")
    z = open("towns.txt","r")
    file_contents = z.read()
    print (file_contents) 
    z.close()    
    busrouteend = input("where do you want to stop?")
    direction2 = input("north, east, south, west?")
    bussv.write(str(busroutestart)+","+str(direction)+"--->"+busrouteend+","+direction2+"\n")
    pass    
    
    
if vehiclebuy == "plane":
    print("PLANE HAS BEEN BOUGHT!! AND STORED")
    z = open("plane.txt","a")
    planecount = planecount + 1
    z.write(str(planecount))
    money = money - 4000
    print("\n")
    print(str(money))
    print("pounds left")
    z.close()
    z = open("towns.txt","r")
    file_contents = z.read()
    print (file_contents) 
    z.close()
    print("\n")
    print("\n")
    print("\n")
    print("\n")
    planeroutestart= input("where do you want it to start? ")
    direction = input("north, east, south, west?")
    planesv= open("planeroute.txt","a")
    z = open("towns.txt","r")
    file_contents = z.read()
    print (file_contents) 
    z.close()    
    planerouteend = input("where do you want to stop?")
    direction2 = input("north, east, south, west?")
    planesv.write(str(planeroutestart)+","+str(direction)+"--->"+planerouteend+","+direction2+"\n")
    pass    
    
if vehiclebuy == "train":
    print("TRAIN HAS BEEN BOUGHT!! AND STORED")
    z = open("train.txt","a")
    traincount = traincount + 1
    z.write(str(traincount))
    money = money - 2000
    print("\n")
    print(str(money))
    print("pounds left")
    z.close()
    z = open("towns.txt","r")
    file_contents = z.read()
    print (file_contents) 
    z.close()
    print("\n")
    print("\n")
    print("\n")
    print("\n")
    trainroutestart= input("where do you want it to start? ")
    direction = input("north, east, south, west?")
    trainsv= open("trainroute.txt","a")
    z = open("towns.txt","r")
    file_contents = z.read()
    print (file_contents) 
    z.close()    
    trainrouteend = input("where do you want to stop?")
    direction2 = input("north, east, south, west?")
    trainsv.write(str(trainroutestart)+","+str(direction)+"--->"+trainrouteend+","+direction2+"\n")
    pass


